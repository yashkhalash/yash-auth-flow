![yash-auth-flow logo](https://unpkg.com/yash-auth-flow@latest/assets/yash-auth-flow.png)

# yash-auth-flow

A powerful, multi-account authentication library for Node.js, Prisma, and PostgreSQL.

## Features

- **Multi-Account Support**: Manage multiple account types (e.g., Personal, Work) under a single User identity.
- **Dynamic Verification**: Built-in support for 6-digit OTP and UUID-based email verification links.
- **Security First**: Pre-configured with Helmet, Express Rate Limit, and Bcrypt (12 rounds).
- **JWT Based**: Modern access and refresh token management.
- **Prisma Integration**: Ships with a ready-to-use Prisma schema.
- **Email Templates**: Sleek, ready-to-send HTML templates for verification.
- **Verification Preference**: Users can choose their preferred verification type (`OTP` or `LINK`) via their profile, falling back to system defaults.

## Installation

```bash
npm install yash-auth-flow
```

## Quick Start

### 1. Setup Prisma
Copy the provided schema from `prisma/schema.prisma` to your project and run:
```bash
npx prisma db push
```

### 2. Configure Environment Variables
Create a `.env` file based on `.env.example`:
```env
DATABASE_URL="postgresql://..."
ACCESS_TOKEN_SECRET="your-secret"
REFRESH_TOKEN_SECRET="your-secret"
```

### 3. Usage Example

```typescript
import { AuthService, authMiddleware, UserService } from 'yash-auth-flow';
import express from 'express';

const app = express();
app.use(express.json());

// Registration
app.post('/register', async (req, res) => {
  const { email, password, fullName } = req.body;
  const result = await AuthService.register(email, password, fullName);
  res.json(result);
});

// Protected Route
app.get('/profile', authMiddleware, (req: any, res) => {
  res.json({ user: req.user, account: req.account });
});

// Edit Profile (Change Verification Type)
app.put('/profile/edit', authMiddleware, async (req: any, res) => {
  const { verificationType } = req.body;
  const result = await UserService.editProfile(req.user.id, { verificationType });
  res.json(result);
});

app.listen(3000);
```

## Multi-Account Logic
AuthForge allows a `User` to have multiple `Accounts`. For example:
- A user can login with `type: "personal"`
- Later, they can create or link an account with `type: "work"`
- Both accounts belong to the same `User.id`, allowing shared profiles or settings.
